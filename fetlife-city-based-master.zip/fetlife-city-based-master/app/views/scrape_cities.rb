require_relative '../controllers/city_scraper'
require 'pry'

# nicebo8281:2vuaGg9LeSfaSks
# cadot92133:2vuaGg9LeSfaSks -- 16796650

scraper = CityScraper.new(
  'nicebo8281',
  '2vuaGg9LeSfaSks',
  'canada',
  'ontario'
)

if scraper.login
  puts Rainbow('Logged in successfully').green
else
  puts Rainbow('Login failed').red
  scraper.quit
end

cities_urls = scraper.scrape_cities
puts Rainbow("#{cities_urls.count} cities found").aqua

start_from = Profile.last.city.present? ? cities_urls.find_index("https://fetlife.com/p/#{Profile.last.country}/#{Profile.last.state}/#{Profile.last.city}") : 0

cities_urls[start_from + 1..].each do |city_url|
  puts "Attempting: #{city_url}"
  scraper.city_kinksters(city_url)
  next unless scraper.kinksters?

  puts Rainbow("#{scraper.kinksters_count} kinksters available").blue

  until scraper.account_locked?
    if scraper.account_locked?
      puts Rainbow('Account locked').red
      break
    end

    scraper.parse_users

    break unless scraper.next_page
  end
end

scraper.quit
