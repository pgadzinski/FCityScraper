# This is where you can create initial data for your app.
OfUser.all.each do |user|
  profile = user.profile
  profile.friends_count = user.friends_count
  profile.followers_count = user.followers_count
  profile.onlyfans = user.onlyfans?
  profile.about = user.about
  profile.websites = user.websites

  profile.save
  # puts profile.inspect
end
