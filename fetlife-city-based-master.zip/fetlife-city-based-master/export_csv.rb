require 'csv'

require_relative 'config/application'

profiles = Profile.where(onlyfans: true)
regexp = /(onlyfans.com\/\S*)/i

CSV.open('onlyfans_users.csv', 'a+') do |csv|
  csv << ['user_id', 'username', 'profile_url', 'friends', 'followers', 'onlyfans 1', 'onlyfans 2'] if csv.count.eql? 0
  profiles.each do |profile|
    onlyfans_urls = []
    onlyfans_urls << profile.about.scan(regexp) unless profile.about.nil?
    onlyfans_urls << profile.websites.scan(regexp) unless profile.websites.nil?
    urls = onlyfans_urls.flatten.map do |url|
      "https://#{url.downcase}"
    end

    row = [profile.user_id, profile.username, profile.profile_url, profile.friends_count, profile.followers_count]
    csv << row.concat(urls)
  end
end
