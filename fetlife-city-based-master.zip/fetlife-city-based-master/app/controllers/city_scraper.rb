# frozen_string_literal: true

require_relative '../../config/application'

class CityScraper
  def initialize(username, password, country, state, city = nil, starting_point = 1)
    @username = username
    @password = password
    @country = country
    @state = state
    @city = city
    @starting_point = starting_point
    options = Selenium::WebDriver::Chrome::Options.new(args: ['headless'])
    @driver = Selenium::WebDriver.for(:chrome, options: options)
    # @driver = Selenium::WebDriver.for(:firefox)
    @base_url = 'https://fetlife.com'
    @driver.get('https://fetlife.com/users/sign_in')
    @driver.manage.timeouts.implicit_wait = 10
  end

  def login
    user_input = @driver.find_element(id: 'user_login')
    user_input.send_keys(@username)

    pass_input = @driver.find_element(id: 'user_password')
    pass_input.send_keys(@password)
    sleep 2
    login_button = @driver.find_element(css: '[name="button"]')
    login_button.click

    @driver.title.include?('Home')
  end

  def scrape_cities
    @driver.navigate.to("#{@base_url}/p/#{@country}/#{@state}/related")
    cities_list_el = @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/main/div')
    cities_list_el.find_elements(tag_name: 'a').map { |el| el.attribute('href') }
  end

  def city_kinksters(url = nil)
    if url.nil?
      @driver.navigate.to("#{@base_url}/p/#{@country}/#{@state}/#{@city}/kinksters/#{@starting_point}")
    else
      @driver.navigate.to("#{url}/kinksters/")
      @city = url.split('/').last
    end
  end

  def parse_users
    puts Rainbow("Parsing #{@driver.title}(#{@driver.current_url})").green
    users_section = @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/main/div')
    users_count = users_section.find_elements(css: 'div.w-50-ns.w-100.ph1').count
    users_count.times do |i|
      profile_details_el = @driver.find_element(
        xpath: "//*[@id=\"ptr-main-element\"]/div[2]/div/main/div/div[#{i + 1}]/div/div/div/div[1]/div[2]/div[1]"
      )
      profile_link_el = profile_details_el.find_element(tag_name: 'a')
      status = profile_details_el.find_element(css: 'span.f6.font-bold.gray-300').text
      profile = Profile.new(
        profile_id: profile_link_el.attribute('href').split('/').last.to_i,
        username: profile_link_el.text,
        profile_url: profile_link_el.attribute('href'),
        country: @country,
        state: @state,
        city: @city
      )
      profile.save if status.match?(/^[0-9]*F/)
    end
  end

  def kinksters?
    !@driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/main/header/div[2]').text.include?('Nothing to show :(')
  rescue Selenium::WebDriver::Error::NoSuchElementError
    false
  end

  def kinksters_count
    @driver.find_element(xpath: '//*[@id="ptr-main-element"]/header/div/nav/div/a[2]/div/div/span/span')
           .text
           .split(',')
           .join('')
           .to_i
  end

  def next_page
    next_btn = @driver.find_element(class: 'next_page')
    if !next_btn.nil? && next_btn.enabled?
      puts Rainbow("Next page available").cyan
      next_btn.click
      true
    end
  rescue Selenium::WebDriver::Error::NoSuchElementError, Selenium::WebDriver::Error::ElementNotInteractableError
    puts Rainbow("Next page not available").magenta
    false
  end

  def account_locked?
    @driver.title.include?('Temporarily Locked Out')
  end

  def quit
    @driver.quit
  end
end
