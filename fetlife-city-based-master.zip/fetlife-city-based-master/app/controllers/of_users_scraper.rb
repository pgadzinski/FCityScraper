# frozen_string_literal: true

require_relative '../../config/application'

# Scrape FetLife profile data
class OfUsersScraper
  attr_reader :counter, :time_start

  KEYWORDS = ['onlyfans', 'Onlyfans', 'OnlyFans', 'ONLYFANS', 'Only Fans', 'only fans', 'ONLY FANS'].freeze
  def initialize(username, password)
    @username = username
    @password = password
    options = Selenium::WebDriver::Chrome::Options.new(args: ['headless'])
    @driver = Selenium::WebDriver.for(:chrome, options: options)
    # @driver = Selenium::WebDriver.for(:chrome)
    @driver.get('https://fetlife.com/users/sign_in')
    @driver.manage.timeouts.implicit_wait = 1
    @counter = 0
    @time_start = Time.now
  end

  def login
    user_input = @driver.find_element(id: 'user_login')
    user_input.send_keys(@username)

    pass_input = @driver.find_element(id: 'user_password')
    pass_input.send_keys(@password)
    sleep 2
    login_button = @driver.find_element(css: '[name="button"]')
    login_button.click

    @driver.title.include?('Home')
  end

  def parse_profile(profile)
    @driver.navigate.to(profile.profile_url)

    user = OfUser.new(
      profile: profile,
      about: parse_about,
      websites: parse_websites,
      friends_count: parse_friends_count,
      followers_count: parse_followers_count,
      onlyfans?: onlyfans_on_about_section? || onlyfans_on_websites_section?
    )

    @counter += 1 if user.save
    # puts user.inspect
  end

  def parse_friends_count
    puts Rainbow('Parsing friends count...').aqua

    div = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/aside[1]/div/div[1]/div/div[1]') }
    if div&.find_element(tag_name: 'h6')&.text&.include?('Friends')
      @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/aside[1]/div/div[1]/div/div[1]/h6/a/span')&.text.to_i
    else
      puts Rainbow('No friends').yellow
    end
  end

  def parse_followers_count
    puts Rainbow('Parsing followers count...').aqua

    div1 = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/aside[1]/div/div[1]/div/div[1]') }
    div2 = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/aside[1]/div/div[1]/div/div[3]') }

    if div1&.find_element(tag_name: 'h6')&.text&.include?('Followers')
      @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/aside[1]/div/div[1]/div/div[1]/h6/a/span')&.text.to_i
    elsif div2&.find_element(tag_name: 'h6')&.text&.include?('Followers')
      @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/aside[1]/div/div[1]/div/div[3]/h6/a/span')&.text.to_i
    else
      puts Rainbow('No followers').yellow
    end
  end

  def parse_about
    puts Rainbow('Parsing about section...').aqua

    if about_section?
      @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[1]/div')&.text
    else
      puts Rainbow('No about section').yellow
    end
  end

  def parse_websites
    puts Rainbow('Parsing websites section...').aqua

    if websites_section?
      first = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[1]/p') }
      second = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[2]/p') }

      first&.text || second&.text
    else
      puts Rainbow('No websites section').yellow
    end
  end

  def onlyfans_on_about_section?
    if about_section?
      about = @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[1]/div').text
      KEYWORDS.any? { |kw| about.include?(kw) }
    else
      false
    end
  end

  def onlyfans_on_websites_section?
    if websites_section?
      first_websites = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[1]/p') }
      second_websites = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[2]/p') }
      websites = first_websites&.text || second_websites&.text
      KEYWORDS.any? { |kw| websites.include?(kw) }
    else
      false
    end
  end

  def account_locked?
    @driver.title.include?('Temporarily Locked Out')
  end

  def quit
    @driver.quit
  end

  private

  def about_section?
    about_heading = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[1]/h2') }
    about_heading&.text&.include?('About')
  end

  def websites_section?
    first_heading = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[1]/h2') }
    second_heading = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[2]/h2') }

    first_heading&.text&.include?('Websites') || second_heading&.text&.include?('Websites')
  end

  def rescue_exceptions
    yield
  rescue Selenium::WebDriver::Error::NoSuchElementError
    puts Rainbow('Unable to locate element').red
  rescue Selenium::WebDriver::Error::StaleElementReferenceError
    puts Rainbow('Stale Element Reference Error').red
  end
end
