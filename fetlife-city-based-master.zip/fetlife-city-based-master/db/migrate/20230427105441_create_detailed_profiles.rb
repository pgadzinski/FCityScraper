class CreateDetailedProfiles < ActiveRecord::Migration[7.0]
  def change
    create_table :detailed_profiles do |t|
      t.references :profile, null: false, foreign_key: true
      t.integer :followers_count
      t.integer :friends_count
      t.text :about
      t.string :groups
      t.string :fetishes
      t.integer :pictures_count
      t.integer :videos_count
      t.text :html_source

      t.timestamps
    end
  end
end
