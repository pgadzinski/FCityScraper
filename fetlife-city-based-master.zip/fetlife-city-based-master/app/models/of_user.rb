class OfUser < ActiveRecord::Base
  belongs_to :profile
end
