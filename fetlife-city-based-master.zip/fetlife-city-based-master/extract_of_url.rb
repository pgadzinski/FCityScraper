require_relative 'config/application'
require 'uri'
require "csv"

profiles = Profile.where(onlyfans: true)
regexp = /(onlyfans.com\/[a-zA-Z0-9]*)/i

# profiles.each do |profile|
#   urls = []
#   urls << URI.extract(profile.about) unless profile.about.nil?
#   urls << URI.extract(profile.websites) unless profile.websites.nil?

#   onlyfans_urls = urls.flatten.filter { |url| url.include?('onlyfans') }
#   p "#{profile.username}(#{profile.profile_url}) - #{onlyfans_urls[0]}"
# end

onlyfans_urls = []
profiles.each do |profile|
  onlyfans_urls << profile.about.scan(regexp) unless profile.about.nil?
  onlyfans_urls << profile.websites.scan(regexp) unless profile.websites.nil?
end

File.write("ss.csv", onlyfans_urls.uniq.map(&:to_csv).join)
