# frozen_string_literal: true

require_relative '../../config/application'

# Scrape FetLife profile data
class ProfileScraper
  attr_reader :counter

  def initialize(username, password)
    @username = username
    @password = password
    # options = Selenium::WebDriver::Chrome::Options.new(args: ['headless'])
    # @driver = Selenium::WebDriver.for(:chrome, options: options)
    @driver = Selenium::WebDriver.for(:chrome)
    @driver.get('https://fetlife.com/users/sign_in')
    @driver.manage.timeouts.implicit_wait = 10
    @counter = 0
  end

  def login
    user_input = @driver.find_element(id: 'user_login')
    user_input.send_keys(@username)

    pass_input = @driver.find_element(id: 'user_password')
    pass_input.send_keys(@password)
    sleep 2
    login_button = @driver.find_element(css: '[name="button"]')
    login_button.click

    @driver.title.include?('Home')
  end

  def parse_profile(profile)
    puts Rainbow("Starting #{profile.username} - #{profile.profile_url}").magenta
    profile_url = profile.profile_url
    @driver.navigate.to(profile_url)

    about = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div[2]/div/main/div/div[1]/div/div/p[2]')&.text }
    pictures_count = rescue_exceptions { @driver.find_element(xpath: '//*[@id="profile-navigation"]/div/ul/li[3]/div/a/span[3]/span')&.text }
    videos_count = rescue_exceptions { @driver.find_element(xpath: '//*[@id="profile-navigation"]/div/ul/li[4]/div/a/span[3]/span')&.text }

    html_source = @driver.page_source

    profile = DetailedProfile.new(
      profile: profile,
      about: about,
      fetishes: parse_fetishes,
      groups: parse_groups,
      friends_count: parse_friends_count(profile_url),
      followers_count: parse_followers_count(profile_url),
      pictures_count: pictures_count,
      videos_count: videos_count,
      html_source: html_source
    )

    puts profile.inspect
    # @counter += 1 if profile.save
  end

  def parse_friends_count(profile_url)
    puts Rainbow('Parsing friends count...').aqua
    @driver.navigate.to("#{profile_url}/friends")
    @driver.find_element(xpath: '//*[@id="ptr-main-element"]/header/div/nav/div/a[1]/div/div/span/span')&.text
  rescue Selenium::WebDriver::Error::NoSuchElementError
    puts Rainbow('No friends').yellow
  end

  def parse_followers_count(profile_url)
    puts Rainbow('Parsing followers count...').aqua
    @driver.navigate.to("#{profile_url}/followers")
    @driver.find_element(xpath: '//*[@id="ptr-main-element"]/header/div/nav/div/a[3]/div/div/span/span')&.text
  rescue Selenium::WebDriver::Error::NoSuchElementError
    puts Rainbow('No followers').yellow
  end

  def parse_fetishes
    puts Rainbow('Parsing fetishes...').aqua
    rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div[2]/div/main/div/div[4]/div/div/a').click }
    @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div[2]/div/main/div/div[4]/div/div/div')&.text
  rescue Selenium::WebDriver::Error::NoSuchElementError
    puts Rainbow('No fetishes').yellow
  end

  def parse_groups
    puts Rainbow('Parsing groups...').aqua
    groups_ul = rescue_exceptions { @driver.find_element(:xpath, '//*[@id="ptr-main-element"]/div[2]/div/div[2]/div/aside[1]/div/div[3]/div[2]/ul') }
    groups_arr = groups_ul&.find_elements(css: 'li')&.map do |li|
      li.find_element(css: 'a')&.text
    end
    groups_arr&.join(', ')
  end

  def account_locked?
    @driver.title.include?('Temporarily Locked Out')
  end

  def valid_profile?
    @driver.title.include?('Kinksters')
  end

  def female_profile?
    return false unless valid_profile?

    el = @driver.find_element(:xpath, '//*[@id="ptr-main-element"]/div[2]/div/header[1]/div/div[1]/main/div/div[1]/div[2]/h1/span[2]')
    el.text.match?(/^[0-9]*F/)
  end

  def quit
    @driver.quit
  end

  private

  def rescue_exceptions
    yield
  rescue Selenium::WebDriver::Error::NoSuchElementError
    puts Rainbow("Unable to locate element").red
  rescue Selenium::WebDriver::Error::StaleElementReferenceError
    puts Rainbow("Stale Element Reference Error").red
  end
end
