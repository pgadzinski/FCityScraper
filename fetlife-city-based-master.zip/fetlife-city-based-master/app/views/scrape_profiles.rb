require_relative '../controllers/profile_scraper'

# nicebo8281:2vuaGg9LeSfaSks
# cadot92133:2vuaGg9LeSfaSks -- 16796650

scraper = ProfileScraper.new('nicebo8281', '2vuaGg9LeSfaSks')

if scraper.login
  puts Rainbow('Logged in successfully').green
else
  puts Rainbow('Login failed').red
  scraper.quit
end

last_scraped_profile = DetailedProfile.last.profile_id unless DetailedProfile.last.nil?
start_from = last_scraped_profile.nil? ? 0 : last_scraped_profile

# loop through profiles in profiles table
Profile.all[start_from..].each do |profile|
  if scraper.account_locked?
    puts Rainbow('Account locked').red
    break
  end

  scraper.parse_profile(profile)
end

scraper.quit
