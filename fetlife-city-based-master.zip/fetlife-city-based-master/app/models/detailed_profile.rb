class DetailedProfile < ActiveRecord::Base
  belongs_to :profile
end
