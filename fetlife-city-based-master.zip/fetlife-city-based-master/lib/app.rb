require 'sinatra'
require 'better_errors'

configure :development do
  use BetterErrors::Middleware
  BetterErrors.application_root = File.expand_path('__dir__')
end

require_relative "../config/application"

set :root, File.expand_path("..", __dir__)
set :views, (proc { File.join(root, "app/views") })
set :bind, '0.0.0.0'
set :port, 3000

after do
  ActiveRecord::Base.connection.close
end

get '/' do
  @profiles = Profile.all.where(onlyfans: true)

  erb :profiles
end
