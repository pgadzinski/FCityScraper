class Profile < ActiveRecord::Base
  has_one :detailed_profile
  has_one :of_user
  validates :user_id, uniqueness: true
end
