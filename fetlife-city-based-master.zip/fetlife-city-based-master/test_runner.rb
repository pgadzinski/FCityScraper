require 'selenium-webdriver'
require 'webdrivers'
require 'rainbow'

# frozen_string_literal: true

require_relative 'config/application'
require_relative 'app/models/of_user'

class TestRunner
  attr_reader :counter

  KEYWORDS = ['onlyfans', 'Onlyfans', 'OnlyFans', 'ONLYFANS', 'Only Fans', 'only fans', 'ONLY FANS'].freeze
  def initialize(username, password)
    @username = username
    @password = password
    # options = Selenium::WebDriver::Chrome::Options.new(args: ['headless'])
    # @driver = Selenium::WebDriver.for(:chrome, options: options)
    @driver = Selenium::WebDriver.for(:chrome)
    @driver.get('https://fetlife.com/users/sign_in')
    @driver.manage.timeouts.implicit_wait = 10
    @counter = 0
  end

  def login
    user_input = @driver.find_element(id: 'user_login')
    user_input.send_keys(@username)

    pass_input = @driver.find_element(id: 'user_password')
    pass_input.send_keys(@password)
    sleep 2
    login_button = @driver.find_element(css: '[name="button"]')
    login_button.click

    @driver.title.include?('Home')
  end

  def open_profile(profile_url)
    @driver.navigate.to(profile_url)
  end

  def parse_profile(profile_url)
    user = OfUser.new(
      about: parse_about,
      websites: parse_websites,
      friends_count: parse_friends_count(profile_url),
      followers_count: parse_followers_count(profile_url),
    )

    puts user.inspect
  end

  def parse_friends_count(profile_url)
    puts Rainbow('Parsing friends count...').aqua
    @driver.navigate.to("#{profile_url}/friends")
    @driver.find_element(xpath: '//*[@id="ptr-main-element"]/header/div/nav/div/a[1]/div/div/span/span')&.text.to_i
  rescue Selenium::WebDriver::Error::NoSuchElementError
    puts Rainbow('No friends').yellow
  end

  def parse_followers_count(profile_url)
    puts Rainbow('Parsing followers count...').aqua
    @driver.navigate.to("#{profile_url}/followers")
    @driver.find_element(xpath: '//*[@id="ptr-main-element"]/header/div/nav/div/a[3]/div/div/span/span')&.text.to_i
  rescue Selenium::WebDriver::Error::NoSuchElementError
    puts Rainbow('No followers').yellow
  end

  def parse_about
    about_heading = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[1]/h2') }
    if about_heading&.text&.include?('About')
      puts 'About section available'
      @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[1]/div').text
    else
      puts 'No about section'
    end
  end

  def parse_websites
    websites_heading = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[2]/h2') }
    if websites_heading&.text&.include?('Websites')
      puts 'Websites section available'
      @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[2]/p').text
    else
      puts 'No websites section'
    end
  end

  def onlyfans_on_about?
    # //*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[1]/h2
    about_heading = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[1]/h2') }
    if about_heading&.text&.include?('About')
      about = @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[1]/div').text
      KEYWORDS.any? { |kw| about.include?(kw) }
    else
      false
    end
  end

  def onlyfans_on_websites?
    # //*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[3]/div/h2
    websites_heading = rescue_exceptions { @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[2]/h2') }
    if websites_heading&.text&.include?('Websites')
      puts 'Websites section available'
      websites = @driver.find_element(xpath: '//*[@id="ptr-main-element"]/div[2]/div/div/div/main/div/div[2]/p').text
      KEYWORDS.any? { |kw| websites.include?(kw) }
    else
      puts 'No websites section'
      false
    end
  end

  def account_locked?
    @driver.title.include?('Temporarily Locked Out')
  end

  def quit
    @driver.quit
  end

  private

  def rescue_exceptions
    yield
  rescue Selenium::WebDriver::Error::NoSuchElementError
    puts Rainbow("Unable to locate element").red
  rescue Selenium::WebDriver::Error::StaleElementReferenceError
    puts Rainbow("Stale Element Reference Error").red
  end
end

scraper = TestRunner.new('nicebo8281', '2vuaGg9LeSfaSks')

if scraper.login
  puts Rainbow('Logged in successfully').green
else
  puts Rainbow('Login failed').red
  scraper.quit
end

profile_urls = [
  'https://fetlife.com/users/15617639',
  'https://fetlife.com/users/15446321',
  'https://fetlife.com/users/11447721',
  'https://fetlife.com/users/1272766',
  'https://fetlife.com/users/12739380'
]

profile_urls.each do |profile_url|
  puts "Profile: #{Rainbow(profile_url).magenta}"
  scraper.open_profile(profile_url)

  scraper.parse_profile(profile_url) if scraper.onlyfans_on_about? || scraper.onlyfans_on_websites?
end
