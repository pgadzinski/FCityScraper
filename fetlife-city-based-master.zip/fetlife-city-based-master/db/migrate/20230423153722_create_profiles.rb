class CreateProfiles < ActiveRecord::Migration[7.0]
  def change
    create_table :profiles do |t|
      t.string :profile_id
      t.string :username
      t.string :profile_url
      t.string :country
      t.string :state
      t.string :city
      t.timestamps # add 2 columns, `created_at` and `updated_at`
    end
  end
end
