require_relative '../controllers/of_users_scraper'

# nicebo8281:2vuaGg9LeSfaSks
# cadot92133:2vuaGg9LeSfaSks -- 16796650

scraper = OfUsersScraper.new('nicebo8281', '2vuaGg9LeSfaSks')

if scraper.login
  puts Rainbow('Logged in successfully').green
else
  puts Rainbow('Login failed').red
  scraper.quit
end

last_scraped_profile = OfUser.last.profile_id unless OfUser.last.nil?
start_from = last_scraped_profile.nil? ? 0 : last_scraped_profile

# loop through profiles in profiles table
Profile.all[start_from..].each do |profile|
  start_time = Time.now
  puts Rainbow("Profile: #{profile.id} - #{profile.profile_url}").magenta
  if scraper.account_locked?
    puts Rainbow('Account locked').red
    break
  end

  scraper.parse_profile(profile)
  puts Rainbow('--------------------------').green
  puts Rainbow("Time taken to scrape profile: #{(Time.now - start_time).to_i}s").green
  puts Rainbow("#{scraper.counter} profiles scraped in #{(Time.now - scraper.time_start).to_i} seconds").green
  puts Rainbow('--------------------------').green
end

scraper.quit
