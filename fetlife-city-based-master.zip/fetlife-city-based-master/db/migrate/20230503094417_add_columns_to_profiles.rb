class AddColumnsToProfiles < ActiveRecord::Migration[7.0]
  def change
    add_column :profiles, :friends_count, :integer
    add_column :profiles, :followers_count, :integer
    add_column :profiles, :onlyfans, :boolean
    add_column :profiles, :about, :string
    add_column :profiles, :websites, :string
  end
end
