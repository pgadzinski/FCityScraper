class CreateOfUsers < ActiveRecord::Migration[7.0]
  def change
    create_table :of_users do |t|
      t.references :profile, null: false, foreign_key: true
      t.integer :friends_count
      t.integer :followers_count
      t.string :about
      t.string :websites

      t.timestamps
    end
  end
end
